<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Alamat_svgIcon svgIcon--light</name>
   <tag></tag>
   <elementGuidId>a72c4bc1-5ff1-4d14-9c47-f981ee9229a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>form > div > div.appDrawer > div.appDrawer__panel > div.appLayoutHeading.appLayoutHeading--dark > div.appLayoutHeading__panel > div.appLayoutHeading__actions.appLayoutHeading__actions--left > a.appLayoutHeading__button > svg.svgIcon.svgIcon--light</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Alamat'])[1]/following::*[name()='svg'][2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xmlns</name>
      <type>Main</type>
      <value>http://www.w3.org/2000/svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>svgIcon svgIcon--light</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__layout&quot;)/div[@class=&quot;appLayout&quot;]/div[3]/div[@class=&quot;appDrawer&quot;]/div[@class=&quot;appDrawer__panel&quot;]/div[@class=&quot;addressWrapper&quot;]/form[1]/div[1]/div[@class=&quot;appDrawer&quot;]/div[@class=&quot;appDrawer__panel&quot;]/div[@class=&quot;appLayoutHeading appLayoutHeading--dark&quot;]/div[@class=&quot;appLayoutHeading__panel&quot;]/div[@class=&quot;appLayoutHeading__actions appLayoutHeading__actions--left&quot;]/a[@class=&quot;appLayoutHeading__button&quot;]/svg[@class=&quot;svgIcon svgIcon--light&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alamat'])[1]/following::*[name()='svg'][2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor Telepon'])[1]/following::*[name()='svg'][2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cari Kelurahan / Kecamatan'])[1]/preceding::*[name()='svg'][1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalimantan Barat, Kota Pontianak, Kec. Pontianak Timur, Kel. Saigon'])[1]/preceding::*[name()='svg'][2]</value>
   </webElementXpaths>
</WebElementEntity>
