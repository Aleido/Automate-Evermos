<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Total Model_svgIcon svgIcon--light</name>
   <tag></tag>
   <elementGuidId>1c4d6752-334c-480d-abaa-699a47606853</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.svgIcon.svgIcon--light</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Model'])[1]/preceding::*[name()='svg'][2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xmlns</name>
      <type>Main</type>
      <value>http://www.w3.org/2000/svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>svgIcon svgIcon--light</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__layout&quot;)/div[@class=&quot;appLayout&quot;]/div[@class=&quot;appLayoutHeading appLayoutHeading--dark&quot;]/div[@class=&quot;appLayoutHeading__panel appLayoutHeading__panel--sticky&quot;]/div[@class=&quot;appLayoutHeading__actions appLayoutHeading__actions--left&quot;]/a[@class=&quot;appLayoutHeading__button&quot;]/svg[@class=&quot;svgIcon svgIcon--light&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total Model'])[1]/preceding::*[name()='svg'][2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ammarkids Kaos Anak AR37'])[1]/preceding::*[name()='svg'][2]</value>
   </webElementXpaths>
</WebElementEntity>
