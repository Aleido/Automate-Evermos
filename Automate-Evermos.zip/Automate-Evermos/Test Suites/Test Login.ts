<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>5909295b-4937-464e-9028-524b025690da</testSuiteGuid>
   <testCaseLink>
      <guid>915e2231-fb06-4b2f-9d4e-b605ce707b41</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Evermos</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d8b345db-11bb-42d8-b257-34ebda5681d6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Evermos Negative</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>328e6656-79b5-4a3c-a062-b874e4bca489</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Evermos Negative 2</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
